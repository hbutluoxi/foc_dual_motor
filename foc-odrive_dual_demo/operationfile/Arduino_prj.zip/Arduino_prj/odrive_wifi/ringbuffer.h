#ifndef __RINGBUFFER_H_
#define __RINGBUFFER_H_

#include <stdint.h>
#include <string.h>
#include <Arduino.h>

#define RING_BUF_SIZE 2048L
#define RING_BUF_DEQUENE_SUCCEEDED -1
#define RING_BUF_ENQUEUE_SUCCEEDED -2
#define RING_BUF_PEEK_SUCCEEDED -3
#define RING_BUF_EMPTY -10
#define RING_BUF_OVERFLOW -11
#define RING_BUF_ERROR -12

class RingBuffer
{
public:
    volatile int head;                    //缓冲区头部位置
    volatile int tail;                    //缓冲区尾部位置
    unsigned char ringBuf[RING_BUF_SIZE]; //缓冲区数组

public:
    void init(void);
    void clear(void);
    char enqueueChar(char ch);
    char enqueueArr(char * Arr, int size);
    char dequeueChar(char * ch);
    char dequeueArr(char * Arr, int size);
    char getLine(char * line);
    char peekChar(char * ch);
    char isEmpty(void);
    char isOverflow(void);
    int  available(void);
    int  availableLine(void);
    int  freeSpace(void);
    int  size(void);
	int  hasCRLFRingBuffer(void);
	bool canEnqueue(int charNum);
};
#endif
