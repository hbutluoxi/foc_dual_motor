#include "wifiPort.h"

WifiPort::WifiPort(void)
{
    WiFiRB.init();
}

WifiPort::~WifiPort(void)
{
}

void WifiPort::begin(int32_t port)
{
    server.begin(port);
    server.setNoDelay(false);
}

bool WifiPort::hasConnect(void)
{
    bool res = false;
    if(serverClient.connected() == true)
    {
        res = true;
    }
    return res;
}

void WifiPort::stop(void)
{
    server.stop();
    WifiPort::clear();
}

bool WifiPort::refreshData(void)
{
    //检测是否有新的client请求进来
    if(server.hasClient())
    {
        //释放旧无效或者断开的client
        serverClient.stop();
        //分配最新的client
        serverClient = server.available();
    }
    //检测client发过来的数据
    bool isReceived = false;
    if(serverClient.connected())
    {
        int packetSize = serverClient.available();
        if(packetSize > 0)
        {
            char * readBuf = new char[packetSize];
            serverClient.read((uint8_t *)readBuf, packetSize);
            WiFiRB.enqueueArr(readBuf, packetSize);
            isReceived = true;
            delete[] readBuf;
        }
    }
    return isReceived;
}

int WifiPort::available(void)
{
    return WiFiRB.available();
}

int WifiPort::availableLine(void)
{
    return WiFiRB.availableLine();
}

void WifiPort::read(char * buf, int num)
{
    WiFiRB.dequeueArr(buf, num);
}

void WifiPort::readAll(char * buf, int * num)
{
    WiFiRB.dequeueArr(buf, WiFiRB.available());
}

void WifiPort::readLine(char * buf)
{
    WiFiRB.getLine(buf);
}

bool WifiPort::readPacket(char * buf)
{
    bool isReceived = false;
    //检测是否有新的client请求进来
    if(server.hasClient())
    {
        //释放旧无效或者断开的client
        serverClient.stop();
        //分配最新的client
        serverClient = server.available();
    }
    //检测client发过来的数据
    if(serverClient.connected())
    {
        int packetSize = serverClient.available();
        if(packetSize > 0)
        {
            serverClient.read((uint8_t *)buf, packetSize);
            buf[packetSize] = '\0';
            isReceived = true;
            serverClient.flush();
        }
    }
    return isReceived;
}

bool WifiPort::hasPacket()
{
    return serverClient.available() != 0 ? true : false;
}

void WifiPort::write(char * buf, int num)
{
    if(serverClient.connected())
    {
        serverClient.write(buf, num);
        serverClient.flush();
    }
}

void WifiPort::print(char * str)
{
	WifiPort::write(str, strlen(str));
}

void WifiPort::println(char * str)
{
    WifiPort::write(str, strlen(str));
    WifiPort::write("\r\n", strlen("\r\n"));
}

bool WifiPort::isWriteOver(void)
{
}

char WifiPort::peek(void)
{
    char ch;
    WiFiRB.peekChar(&ch);
    return ch;
}

void WifiPort::clear(void)
{
    WiFiRB.init();
    if(serverClient.connected())
    {
        serverClient.flush();
    }
}