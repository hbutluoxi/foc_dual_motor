#ifndef __WIFIPORT_PC_H_
#define __WIFIPORT_PC_H_

#include <WiFi.h>
#include "WiFiClient.h"
#include "ringbuffer.h"

class WifiPort
{
public:
    RingBuffer WiFiRB;
    WiFiServer server;
    WiFiClient serverClient;

public:

    WifiPort(void);
    ~WifiPort(void);

    void begin(int32_t port);           // 建立连接
    bool hasConnect(void);              // 判断是否有连接
    void stop(void);                    // 断开连接

    bool refreshData(void);             // 把数据添加到环形缓冲区中

    int  available(void);               // 缓冲区中可用字符数
    int  availableLine(void);           // 缓冲区中可用行数

    void read(char * buf, int num);     // 读出缓冲区中指定数量的数据
    void readAll(char * buf, int * num); // 读出缓冲区中所有数据
    void readLine(char * buf);          // 从换从区中读出一行以'\n'结尾的数据
    bool readPacket(char * buf);
    bool hasPacket();

    void write(char * buf, int num);    // 发送数据
    void print(char * str);             // 发送字符串
    void println(char * str);           // 发送字符串并添加回车换行符
    bool isWriteOver(void);             // 判断是否发送完毕

    char peek(void);                    // 读取首字节数据，但并不从接收缓存中删除它
    void clear(void);                   // 清除缓冲区中所有数据
};

#endif
